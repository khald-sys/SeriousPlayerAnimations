package com.animation.serious.mixin;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin extends HumanoidModel<AvatarRenderState> {
    protected PlayerModelMixin(ModelPart root) {
        super(root);
    }

    @Inject(method = "setupAnim", at = @At("TAIL"))
    private void serious$applyMotion(AvatarRenderState state, CallbackInfo ci) {
        float speed = Mth.clamp(state.walkAnimationSpeed, 0.0F, 1.0F);
        if (speed < 0.01F || state.isCrouching) return;

        this.body.xRot += 0.15F * speed;
        this.head.xRot -= 0.10F * speed;
        this.body.zRot += Mth.sin(state.walkAnimationPos * 0.6662F) * 0.05F * speed;
    }
}
