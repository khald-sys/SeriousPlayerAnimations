package com.animation.serious;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SeriousPlayerAnimationsClient implements ClientModInitializer {
    public static final String MOD_ID = "serious_player_animations";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Serious Player Animations loaded for Minecraft 1.21.11");
    }
}
