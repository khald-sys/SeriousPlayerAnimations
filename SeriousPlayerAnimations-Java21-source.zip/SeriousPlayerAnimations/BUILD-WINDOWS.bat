@echo off
echo This project targets Minecraft 1.21.11, Fabric, and Java 21.
echo Install JDK 21 and Gradle, then run: gradle build
echo The JAR will be placed in build\libs after a successful build.
pause
