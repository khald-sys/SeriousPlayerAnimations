# Serious Player Animations

Client-side Fabric mod source adapted for **Minecraft 1.21.11 + Java 21**. It adds a subtle torso lean and side sway while walking.

## Important
- This is a source project, not a prebuilt JAR.
- The build was **not compiled or game-tested** in the current environment: Gradle is not installed and external dependency downloads are unavailable.
- Minecraft 26.2 requires Java 25; to target Java 21, this project was moved to Minecraft 1.21.11. The 1.21.11 mappings include `AvatarRenderState`, so the mixin is written for that API generation.

## Build
Use JDK 21 and a compatible Gradle installation, then run from this directory:

```sh
gradle build
```

The output JAR should be in `build/libs/` after a successful build. If Loom cannot resolve `1.14-SNAPSHOT`, update the Loom version to a stable release compatible with Minecraft 1.21.11.
